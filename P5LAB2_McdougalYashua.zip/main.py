def feet_to_steps(feet):
    a = feet // 2.5
    return int(a)


if __name__ == '__main__':
    user_feet=float(input())
    steps=feet_to_steps(user_feet)
    print(steps)
