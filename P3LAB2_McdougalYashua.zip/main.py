print("Enter desired auto service:")
s = input()
print("You entered:",s)
if(s=="Oil change"):
    print("Cost of "+str(s.lower())+": $35")
elif(s=="Tire rotation"):
    print("Cost of " + str(s.lower()) + ": $19")
elif(s=="Car wash"):
    print("Cost of " + str(s.lower()) + ": $7")
else:
    print("Error: Requested service is not recognized")